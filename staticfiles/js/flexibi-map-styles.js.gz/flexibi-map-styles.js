const catchment_layer_style = {
    "color": "#04555E"
}

const region_layer_style = {
    "color": "#A1221C",
    "fillOpacity": 0.0
}

